Rails.application.routes.draw do
  resources :posts
  devise_for :users
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  post 'comments/create', to:'comments#create',as: :comments
  delete 'comments/:id', to:'comments#destroy',as: :destroy_comment
  root "home#index"

end
