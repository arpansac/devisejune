class CommentsController < ApplicationController
	def create
		@comment=Comment.new(content:params[:comment][:content],post_id:params[:comment][:post_id])
		@comment.user_id=current_user.id
		@comment.save
		return redirect_to post_path(params[:comment][:post_id])
	end

	def destroy
		@comment=Comment.find(params[:id])
		@comment.destroy
		return redirect_to post_path(@comment.post_id)
	end
end

